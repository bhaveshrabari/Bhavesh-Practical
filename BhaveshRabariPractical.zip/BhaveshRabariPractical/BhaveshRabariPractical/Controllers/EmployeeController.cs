﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace BhaveshRabariPractical.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {
            BhaveshPracticalEntities db = new BhaveshPracticalEntities();
            var Emp = db.vw_getEmployees.ToList();
            return View(Emp);
        }
        // GET: Employee/Details/5
        public ActionResult Details(int id)
        {

            return View();
        }

        // GET: Employee/Create
        public ActionResult Create()
        {
            using (BhaveshPracticalEntities db = new BhaveshPracticalEntities())
            {
                var dbDep = new SelectList(db.Departments.ToList(), "DepartmentID", "DepartmentName");
                ViewData["DBDepartment"] = dbDep;
            }
            //ViewBag.dropdownVD = new SelectList(DB.tblStuds.ToList(), "studid", "stud_name");
            //return View();  
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                using (BhaveshPracticalEntities db = new BhaveshPracticalEntities())
                {
                    Employee emp = new Employee();
                    //  
                    emp.EmployeeID = Convert.ToInt32(collection["EmployeeID"]);
                    emp.Name = collection["Name"].ToString();
                    emp.Surname = collection["Surname"].ToString();
                    emp.Address = collection["Address"].ToString();
                    emp.Qualification = collection["Qualification"].ToString();
                    emp.Contact = collection["Contact"].ToString();
                    emp.DepartmentID = Convert.ToInt32(collection["ddDepartment"]);
                    //  
                    db.Employees.Add(emp);
                    //  
                    int i = db.SaveChanges();
                    if (i > 0)
                    {
                        ViewBag.Msg = "Data Saved Suuceessfully.";
                    }
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/Edit/5
        public ActionResult Edit(int id)
        {
            BhaveshPracticalEntities db = new BhaveshPracticalEntities();
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var employee = db.Employees.SingleOrDefault(e => e.EmployeeID == id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            using (BhaveshPracticalEntities db2 = new BhaveshPracticalEntities())
            {
                var dbDep = new SelectList(db2.Departments.ToList(), "DepartmentID", "DepartmentName");
                ViewData["DBDepartment"] = dbDep;
            }

            return View(employee);
        }

        // POST: Employee/Edit/5
        [HttpPost]
        public ActionResult Edit(Employee emp)
        {
            BhaveshPracticalEntities db = new BhaveshPracticalEntities();
            try
            {
                if (ModelState.IsValid)
                {
                    db.Entry(emp).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View(emp);
            }
            catch
            {
                return View();
            }
        }

        // GET: Employee/Delete/5
        public ActionResult Delete(int id)
        {
            BhaveshPracticalEntities _context = new BhaveshPracticalEntities();

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var emp = _context.Employees.SingleOrDefault(e => e.EmployeeID == id);
            if (emp == null)
            {
                return HttpNotFound();
            }
            return View(emp);
        }

        // POST: Employee/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            BhaveshPracticalEntities db = new BhaveshPracticalEntities();
            try
            {
                var emp = db.Employees.SingleOrDefault(x => x.EmployeeID == id);
                db.Employees.Remove(emp);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
