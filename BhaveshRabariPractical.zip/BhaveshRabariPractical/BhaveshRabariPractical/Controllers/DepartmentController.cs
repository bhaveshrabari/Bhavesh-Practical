﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace BhaveshRabariPractical.Controllers
{
    public class DepartmentController : Controller
    {
        // GET: Department
        public ActionResult Index()
        {
            BhaveshPracticalEntities db = new BhaveshPracticalEntities();
            var Departments = db.Departments.ToList();
            return View(Departments);
        }

        // GET: Department/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Department/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Department/Create
        [HttpPost]
        [ValidateAntiForgeryToken]  

        public ActionResult Create(FormCollection collection)
        {
            try
            {
                using (BhaveshPracticalEntities objContext = new BhaveshPracticalEntities())
                {
                    Department Tbl = new Department();
                    //  
                    Tbl.DepartmentID = Convert.ToInt32(collection["DepartmentID"]);
                    Tbl.DepartmentName = collection["DepartmentName"];
                    //  
                    objContext.Departments.Add(Tbl);
                    //  
                    int i = objContext.SaveChanges();
                    if (i > 0)
                    {
                        ViewBag.Msg = "Data Saved Suuceessfully.";
                    }
                }

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Department/Edit/5
        public ActionResult Edit(int id)
        {

            BhaveshPracticalEntities db = new BhaveshPracticalEntities();
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var department = db.Departments.SingleOrDefault(e => e.DepartmentID == id);
            if (department == null)
            {
                return HttpNotFound();
            }
            return View(department);
        }

        // POST: Department/Edit/5
        [HttpPost]
        public ActionResult Edit(Department dp)
        {
            BhaveshPracticalEntities db = new BhaveshPracticalEntities();
            try
            {
                if (ModelState.IsValid)
                {
                    db.Entry(dp).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View(dp);
            }
            catch
            {
                return View();
            }
        }

        // GET: Department/Delete/5
        public ActionResult Delete(int id)
        {
            BhaveshPracticalEntities _context = new BhaveshPracticalEntities();

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var dept = _context.Departments.SingleOrDefault(e => e.DepartmentID == id);
            if (dept == null)
            {
                return HttpNotFound();
            }
            return View(dept);
        }

        // POST: Department/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            BhaveshPracticalEntities db = new BhaveshPracticalEntities();
            try
            {

                var dept = db.Departments.SingleOrDefault(x => x.DepartmentID == id);
                db.Departments.Remove(dept);
                //db.Departments.Remove(dept ?? throw new InvalidOperationException());  

                db.SaveChanges();
                return RedirectToAction("Index");

                //return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
